# Kumpulan Tugas Kuliah

Situs blog statis (HTML, CSS, JavaScript murni) untuk menampilkan tugas kuliah berupa teks, gambar, dan file lampiran. Dosen cukup membuka satu link. Gratis, tanpa server, tanpa database.

## 1. Menaruh situs di GitHub Pages (sekali saja)

1. Buat akun di [github.com](https://github.com), lalu klik **New repository**. Beri nama, misalnya `tugas-kuliah`, pilih **Public**, lalu **Create repository**. (GitHub Pages gratis hanya untuk repository publik.)
2. Di halaman repository, klik **uploading an existing file** (atau **Add file → Upload files**). Seret isi folder proyek ini ke sana: `index.html`, `tugas.html`, folder `css`, `js`, `data`, dan `uploads`. Folder `docs`, `test`, dan `package.json` boleh dilewati.
3. Klik **Commit changes**.
4. Buka **Settings → Pages**. Pada **Build and deployment**, pilih **Source: Deploy from a branch**, **Branch: `main`**, folder **`/ (root)`**, lalu **Save**.
5. Tunggu 1–2 menit. Alamat situs Anda muncul di halaman itu, bentuknya:
   `https://<username-github>.github.io/<nama-repository>/`

Kirim alamat itu ke dosen.

## 2. Mengganti nama, NIM, dan judul situs

Buka `data/tugas.json` di GitHub (klik file, lalu ikon pensil), ubah bagian ini di baris paling atas, lalu **Commit changes**:

```json
"pemilik": { "nama": "Nama Anda", "nim": "NIM Anda" },
"judul_situs": "Kumpulan Tugas Kuliah",
```

## 3. Menambah tugas

1. **Unggah file.** Di repository, buka folder `uploads`, klik **Add file → Upload files**, seret gambar atau file tugas (PDF, DOCX, dan lain-lain), lalu **Commit changes**. Nama file boleh memakai spasi.
2. **Tambah entri.** Buka `data/tugas.json`, klik ikon pensil, dan salin satu blok ini ke dalam daftar `"tugas"` (di atas entri yang sudah ada):

```json
{
  "id": "tugas-2-basis-data",
  "judul": "Tugas 2: Normalisasi",
  "mata_kuliah": "Basis Data",
  "tanggal": "2026-10-27",
  "teks": "Paragraf pertama.\n\nParagraf kedua.",
  "gambar": [
    { "file": "uploads/normalisasi.png", "keterangan": "Hasil normalisasi" }
  ],
  "lampiran": [
    { "file": "uploads/Laporan Tugas 2.pdf", "nama": "Laporan Tugas 2" }
  ]
},
```

3. Klik **Commit changes**. Situs ter-update dalam beberapa menit.

Aturan penting agar tidak error:

- **Wajib:** `id`, `judul`, `mata_kuliah`, `tanggal`. Lainnya (`teks`, `gambar`, `lampiran`) boleh dihapus.
- `id` harus unik dan hanya berisi huruf, angka, `-`, dan `_` (tanpa spasi).
- `tanggal` berformat `TAHUN-BULAN-TANGGAL` dengan nol di depan, misalnya `2026-10-27`.
- Path file harus diawali `uploads/` dan sama persis dengan nama file yang diunggah (huruf besar/kecil berpengaruh).
- Antar entri dipisah koma. **Entri terakhir tidak boleh diikuti koma.** Semua teks memakai tanda kutip ganda `"`.
- Baris baru di dalam `teks` ditulis `\n`. Dua kali (`\n\n`) membuat paragraf baru.
- Tidak perlu mengurutkan: situs menampilkan tugas dari tanggal terbaru.

Sebelum dikumpulkan, hapus tiga entri contoh di `tugas.json` dan file contoh di `uploads/` (`erd-1.svg`, `galeri-1.svg`, `galeri-2.svg`, `galeri-3.svg`, `Laporan Tugas 1.pdf`).

## 4. Kalau ada masalah

| Gejala | Penyebab umum |
|---|---|
| "Data tugas tidak dapat dibaca" | `tugas.json` salah format. Pesan di bawahnya menyebut posisi kesalahan (biasanya koma kurang atau berlebih, atau tanda kutip hilang). |
| Satu tugas tidak muncul | Salah satu field wajib kosong, `id` dobel, atau tanggal salah. Buka konsol browser (F12 → Console) untuk melihat alasannya. |
| "Gambar tidak ditemukan" / "File tidak tersedia" | Nama file di `tugas.json` berbeda dengan nama file di `uploads/`, atau file belum diunggah. |
| Perubahan belum terlihat | Tunggu 1–2 menit lalu muat ulang halaman (Ctrl+F5). |

Batas ukuran: unggah lewat web GitHub maksimal **25 MB per file**. Kompres file yang lebih besar terlebih dahulu.

## 5. Menjalankan di komputer sendiri

Membuka `index.html` dengan klik dua kali tidak akan berfungsi, karena browser memblokir pembacaan `tugas.json` dari `file://`. Jalankan server lokal:

```bash
python3 -m http.server 8000
```

lalu buka `http://localhost:8000/`.

Menjalankan pengujian logika (butuh Node.js 18 atau lebih baru):

```bash
node --test
```
